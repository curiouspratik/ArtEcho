//
//  Configs.swift
//  ArtEcho
//
//  Created by Pratik Ashok Patil on 13/04/24.
//

import Foundation
class Configs{
    static let favouritesTableViewCellID = "favouritesTableViewCellID"
}

// just have a default prompt for each query no need to give user the flexibility for each prompt,
// later in profile view we can set up that prompt in future
